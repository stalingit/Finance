-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2018 at 06:38 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finance`
--

-- --------------------------------------------------------

--
-- Table structure for table `client_details`
--

CREATE TABLE `client_details` (
  `id` int(30) NOT NULL,
  `name` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `relative_name` varchar(200) NOT NULL,
  `age` int(11) NOT NULL,
  `aadhar_no` varchar(200) NOT NULL,
  `address` varchar(255) NOT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `date_of_payment` datetime NOT NULL,
  `total_amount` varchar(200) NOT NULL,
  `interest` int(11) NOT NULL,
  `paid` varchar(200) NOT NULL,
  `balance_amount` varchar(200) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client_details`
--

INSERT INTO `client_details` (`id`, `name`, `phone`, `relative_name`, `age`, `aadhar_no`, `address`, `payment_mode`, `date_of_payment`, `total_amount`, `interest`, `paid`, `balance_amount`, `created`, `modified`, `status`) VALUES
(1, 'Stalin', '9894405547', 'Thomas', 33, '1431743', 'Thirunageswaram,Kumbakonam', 'Monthly', '2018-08-08 00:00:00', '50000', 2, '', '49000', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1'),
(2, 'Thomas', '9894405547', 'Father', 65, '143143', 'Vadagarai,Kumbakonam', 'Monthly', '2018-08-09 00:00:00', '25000', 1, '', '24750', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1'),
(3, 'Mervin', '9894405547', 'Brother', 33, '143143', 'Thirunageswaram,Kumbakonam', 'Monthly', '2018-08-09 00:00:00', '20000', 10, '', '18000', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client_details`
--
ALTER TABLE `client_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client_details`
--
ALTER TABLE `client_details`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
