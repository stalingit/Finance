
<?php
	//include connection file 
	include_once("connection.php");
	
	$db = new dbObj();
	$connString =  $db->getConnstring();

	$params = $_REQUEST;
	
	$action = isset($params['action']) != '' ? $params['action'] : '';
	$empCls = new Employee($connString);

	switch($action) {
	 case 'add':
		$empCls->insertEmployee($params);
	 break;
	 case 'edit':
		$empCls->updateEmployee($params);
	 break;
	 case 'delete':
		$empCls->deleteEmployee($params);
	 break;
	 default:
	 $empCls->getEmployees($params);
	 return;
	}
	
	class Employee {
	protected $conn;
	protected $data = array();
	function __construct($connString) {
		$this->conn = $connString;
	}
	
	public function getEmployees($params) {
		
		$this->data = $this->getRecords($params);
		
		echo json_encode($this->data);
	}
	function insertEmployee($params) {
		$data = array();
		$status= 0;
	$sql = "INSERT INTO `client_details` (name, phone, relative_name,age,aadhar_no,address,payment_mode,date_of_payment,total_amount,interest,balance_amount,status) VALUES('" . $params["name"] . "', '" . $params["contact_no"] . "','" . $params["relative_name"] . "','" . $params["age"] . "','" . $params["aadhar_no"] . "','" . $params["address"] . "','" . $params["payment_mode"] . "','" . $params["date_of_payment"] . "','" . $params["total_amount"] . "','" . $params["interest"] . "',	'" . $params["balance_amount"] . "','".$status."');  ";
	
		
		echo $result = mysqli_query($this->conn, $sql) or die("error to insert employee data");
		
	}
	
	
	function getRecords($params) {
		$rp = isset($params['rowCount']) ? $params['rowCount'] : 10;
		
		if (isset($params['current'])) { $page  = $params['current']; } else { $page=1; };  
        $start_from = ($page-1) * $rp;
		
		$sql = $sqlRec = $sqlTot = $where = '';
		
		if( !empty($params['searchPhrase']) ) {   
			$where .=" WHERE ";
			$where .=" ( name LIKE '".$params['searchPhrase']."%' ";    
			$where .=" OR relative_name LIKE '".$params['searchPhrase']."%' ";

			$where .=" OR age LIKE '".$params['searchPhrase']."%' )";
	   }
	   if( !empty($params['sort']) ) {  
			$where .=" ORDER By ".key($params['sort']) .' '.current($params['sort'])." ";
		}
	   // getting total number records without any search
		$sql = "SELECT * FROM `client_details` ";
		$sqlTot .= $sql;
		$sqlRec .= $sql;
		
		//concatenate search sql if value exist
		if(isset($where) && $where != '') {

			$sqlTot .= $where;
			$sqlRec .= $where;
		}
		if ($rp!=-1)
		$sqlRec .= " LIMIT ". $start_from .",".$rp;
		
		
		$qtot = mysqli_query($this->conn, $sqlTot) or die("error to fetch tot employees data");
		$queryRecords = mysqli_query($this->conn, $sqlRec) or die("error to fetch employees data");
		
		while( $row = mysqli_fetch_assoc($queryRecords) ) { 
			$data[] = $row;
		}

		$json_data = array(
			"current"            => intval($params['current']), 
			"rowCount"            => 10, 			
			"total"    => intval($qtot->num_rows),
			"rows"            => $data   // total data array
			);
		
		return $json_data;
	}
	function updateEmployee($params) {
		$data = array();
		//print_R($_POST);die;
			$sql = "Update `client_details` set name = '" . $params["edit_name"] . "', phone='" . $params["edit_contact_no"]."', relative_name= '" . $params["edit_relative_name"] . "',age= '" . $params["edit_age"] . "',aadhar_no= '" . $params["edit_aadhar_no"] . "',address= '" . $params["edit_address"] . "',payment_mode= '" . @$params["edit_payment_mode"] . "',date_of_payment= '" . $params["edit_date_of_payment"] . "',total_amount= '" . $params["edit_total_amount"] . "',interest= '" . $params["edit_interest"] . "',
	balance_amount= '" . $params["edit_balance_amount"] . "' WHERE id='".$_POST["edit_id"]."'";
	
		
		echo $result = mysqli_query($this->conn, $sql) or die("error to update employee data");
	}
	
	function deleteEmployee($params) {
		$data = array();
		//print_R($_POST);die;
		$sql = "delete from `client_details` WHERE id='".$params["id"]."'";
		
		echo $result = mysqli_query($this->conn, $sql) or die("error to delete employee data");
	}
}
?>
	