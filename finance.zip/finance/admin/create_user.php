<?php 
error_reporting(0);
include_once( "../api.php");?>
<!DOCTYPE html>
<html>
<head>
    <title>Admit Create user</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../css/themes/1/conf-room1.min.css" rel="stylesheet" />
    <link href="../css/themes/1/jquery.mobile.icons.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.css">
	
    <link href="../css/app.css" rel="stylesheet" />
     <script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="../js/settings.js" type="text/javascript"></script>
    <script src="../js/api-messages.js" type="text/javascript"></script>
    <script src="../js/sign-up.js" type="text/javascript"></script>
    <script src="http://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.js"></script>
</head>

<body>
    <div data-role="page" id="page-signup">
        <div data-role="header" data-theme="c">
            <h1>Admin Create user</h1>
        </div><!-- /header -->
        <div role="main" class="ui-content">
            <h3>Sign Up</h3>
            <div id="ctn-err" class="bi-invisible"></div>
            <label for="txt-first-name">First Name</label>
            <input type="text" name="txt-first-name" id="txt-first-name" value="">
            <label for="txt-last-name">Last Name</label>
            <input type="text" name="txt-last-name" id="txt-last-name" value="">
            <label for="txt-email-address">Email Address</label>
            <input type="text" name="txt-email-address" id="txt-email-address" value="">
			 <label for="user_type">User Type</label>
			<select name="user_type" id="user_type" >
				
				<option value="admin">Admin</option>
				<option value="user">User</option>
			</select>
			
			
			
			
			
            <label for="txt-password">Password</label>
            <input type="password" name="txt-password" id="txt-password" value="">
            <label for="txt-password-confirm">Confirm Password</label>
            <input type="password" name="txt-password-confirm" id="txt-password-confirm" value="">
            <!--<a href="#dlg-sign-up-sent" data-rel="popup" data-transition="pop" data-position-to="window" id="btn-submit" class="ui-btn ui-btn-b ui-corner-all mc-top-margin-1-5">Submit</a>-->
            <button id="btn-submit" class="ui-btn ui-btn-b ui-corner-all mc-top-margin-1-5">create user</button>
            <div data-role="popup" id="dlg-sign-up-sent" data-dismissible="false" style="max-width:400px;">
                <div data-role="header">
                    <h1>Almost done...</h1>
                </div>
                <div role="main" class="ui-content">
                    <h3>Confirm Your Email Address</h3>
                    <p>We sent you an email with instructions on how to confirm your email address. Please check your inbox and follow the instructions in the email.</p>
                    <div class="mc-text-center"><a href="sign-in.html" class="ui-btn ui-corner-all ui-shadow ui-btn-b mc-top-margin-1-5">OK</a></div>

                </div>
            </div>
        </div><!-- /content -->
    </div><!-- /page -->
</body>
</html>
