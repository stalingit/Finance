<?php
// config file
define("APP_BASE_URL", "http://localhost/");
define("APP_URL", APP_BASE_URL . "finance/");