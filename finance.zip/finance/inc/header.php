<?php 
// include config file
include_once("inc/config.php");

?>
<!DOCTYPE html>
<html>
<head>
    <title>Conference Room Booking App - Sign In</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo APP_URL;?>css/themes/1/conf-room1.min.css" rel="stylesheet" />
    <link href="<?php echo APP_URL;?>css/themes/1/jquery.mobile.icons.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo APP_URL;?>css/jquery.mobile-1.4.2.min.css">
    <link href="<?php echo APP_URL;?>/css/app.css" rel="stylesheet" />
     <script src="<?php echo APP_URL;?>js/jquery-1.10.2.min.js"></script>
    <script src="<?php echo APP_URL;?>js/settings.js" type="text/javascript"></script>
   <script src="<?php echo APP_URL;?>js/jquery.mobile-1.4.2.min.js"></script>
   <script src="<?php echo APP_URL;?>js/jquery.cookie.js"></script>
	 <script src="<?php echo APP_URL;?>js/sign-in.js" type="text/javascript"></script>
</head>