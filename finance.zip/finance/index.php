﻿<!DOCTYPE html>
<html>
<head>
    <title>BookIt - Welcome</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="./css/themes/1/conf-room1.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.css">
   
    <link href="./css/app.css" rel="stylesheet" />
    <script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="js/settings.js" type="text/javascript"></script>
    <script src="js/api-messages.js" type="text/javascript"></script>
    <script src="js/sign-up.js" type="text/javascript"></script>
    <script src="http://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.js"></script>
</head>

<body>
    <div data-role="page" data-bookit-page="index">
        <div data-role="header" data-theme="c">
            <h1>Book It</h1>
        </div><!-- /header -->
        <div role="main" class="ui-content">
            <h2 class="mc-text-center">Welcome!</h2>
            <p class="mc-top-margin-1-5"><b>Existing Users</b></p>
            <a href="sign-in.php" class="ui-btn ui-btn-b ui-corner-all">Sign In</a>
            <p class="mc-top-margin-1-5"><b>Don't have an account?</b></p>
            <a href="sign-up.php" class="ui-btn ui-btn-b ui-corner-all">Sign Up</a>
            <p></p>
        </div><!-- /content -->
    </div><!-- /page -->
</body>
</html>
