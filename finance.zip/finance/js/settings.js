﻿var BookIt = BookIt || {};
BookIt.Settings = BookIt.Settings || {};
BookIt.Settings.apiUrl = "http://localhost/finance/server/api.php?action=";
BookIt.Settings.signUpUrl = BookIt.Settings.apiUrl + "register";
BookIt.Settings.signInUrl = BookIt.Settings.apiUrl + "login";