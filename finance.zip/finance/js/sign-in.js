﻿(function () {


    var emailAddressIsValid = function (email) {
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    };


    $(document).delegate("#page-signin", "pagebeforecreate", function () { 
	debugger;
        var signInPage = $("#page-signin"),
		
         btnSubmit = $("#btn-submit", signInPage);
// auto login when admin tries to access sign in page
		console.log(" cookie value" +  $.cookie('admin_logged_in') );
		if($.cookie('admin_logged_in') == "true" ){
			alert( 'admi logged in already' );
			$.mobile.navigate("admin.php");
		}

		console.log(" user cookie value" +  $.cookie('user_logged_in') );
		// auto login when user tries to access sign in page
		if($.cookie('user_logged_in') == "true" ){
			$.mobile.navigate("user.php");
		}
		
        btnSubmit.off("tap").on("tap", function () {
		
            
                ctnErr = $("#ctn-err", signInPage),
               txtEmailAddress = $("#txt-email", signInPage),
			  

                 txtPassword = $("#txt-password", signInPage),
    

            
              emailAddress = txtEmailAddress.val().trim(),
                password = txtPassword.val().trim(),
                //passwordConfirm = $txtPasswordConfirm.val().trim(),
                invalidInput = false,
                invisibleStyle = "bi-invisible",
                invalidInputStyle = "bi-invalid-input";

            // Reset styles.
            ctnErr.removeClass().addClass(invisibleStyle);
           // $txtFirstName.removeClass(invalidInputStyle);
           // $txtLastName.removeClass(invalidInputStyle);
            txtEmailAddress.removeClass(invalidInputStyle);
            txtPassword.removeClass(invalidInputStyle);
            //$txtPasswordConfirm.removeClass(invalidInputStyle);

            
            if (emailAddress.length === 0) {
                txtEmailAddress.addClass(invalidInputStyle);
                invalidInput = true;
            }
            if (password.length === 0) {
                txtPassword.addClass(invalidInputStyle);
                invalidInput = true;
            }
            

            // Make sure that all the required fields have values.
            if (invalidInput) {
                ctnErr.html("<p>Please enter all the required fields.</p>");
                ctnErr.addClass("bi-ctn-err").slideDown();
                return;
            }

            if (!emailAddressIsValid(emailAddress)) {
                ctnErr.html("<p>Please enter a valid email address.</p>");
                ctnErr.addClass("bi-ctn-err").slideDown();
                txtEmailAddress.addClass(invalidInputStyle);
                return;
            }

           

            $.ajax({
                type: 'POST',
                url: BookIt.Settings.signInUrl,
				dataType:"json",
                data:"email=" + emailAddress + "&password=" + password ,
                success: function (resp) {
                    console.log("success");
                    if (resp.success === true) {
						$.cookie('user_logged_in', true );
                        $.mobile.navigate("user.php");
                        return;
                    }
					else if(resp.success_admin === true){
						$.cookie('admin_logged_in', true );
						$.mobile.navigate("admin.php");
                        return;
					
					
					}
					else if(resp.success_logout=== true){
						$.cookie('admin_logged_in', undefined );
						$.cookie('user_logged_in', undefined );
						$.mobile.navigate("index.php");					
                        return;
					
					
					}
                    if (resp.msg) {
                        switch (resp.msg) {
                            case BookIt.ApiMessages.DB_ERROR:
                            case BookIt.ApiMessages.COULD_NOT_CREATE_USER:
                                // TODO: Use a friendlier error message below.
                                ctnErr.html("<p>Oops! BookIt had a problem and could not register you.  Please try again in a few minutes.</p>");
                                ctnErr.addClass("bi-ctn-err").slideDown();
                                break;
                            case BookIt.ApiMessages.EMAIL_ALREADY_EXISTS:
                                ctnErr.html("<p>The email address that you provided is already registered.</p>");
                                ctnErr.addClass("bi-ctn-err").slideDown();
                                txtEmailAddress.addClass(invalidInputStyle);
                                break;
                        }
                    }
                    
                },
                error: function (e) {
                    console.log(e.message);
                    // TODO: Use a friendlier error message below.
                    ctnErr.html("<p>Oops! BookIt had a problem and could not register you.  Please try again in a few minutes.</p>");
                    ctnErr.addClass("bi-ctn-err").slideDown();
                }
            });
        });
    
		//logout links
		var logoutLink  = $("#logout", signInPage );
		logoutLink.off('tap').on("top", function(){
			$.cookie('admin_logged_in', undefined );
			$.cookie('user_logged_in', undefined );
			$.mobile.navigate('sign-in.php');
		})
	});
	
	$(document).delegate("#page-signin", "pageload", function(){
	

	});
})();