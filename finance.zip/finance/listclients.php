<?php
// header page inclueds
include_once( "inc/header.php");
// thelist clients pageshould be comehere 
?>
<h3> Clients </h3>
<body>
    <div data-role="page" data-bookit-page="index">
        <div data-role="header" data-theme="c">
            <h1>Book It</h1>
        </div><!-- /header -->
        <div role="main" class="ui-content">
            <h2 class="mc-text-center">Registration Succeed</h2>
            <p class="mc-top-margin-1-5">Congratulations!  You are now registered with BookIt.</p>
		
		<div>
		<a id="logout" class="ui-btn ui-btn-b ui-corner-all">Logout</a>
				
					<strong><?php echo $_SESSION['user']['username']; ?></strong>

					<small>
						<i  style="color: #888;">(test<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i> 
						<br>
						
					  
						&nbsp; <a href="create_user.php"> + add user</a>
					</small>

			</div>
            <!-- <a href="sign-in.html" class="ui-btn ui-btn-b ui-corner-all">Sign In</a>-->
            <p></p>
        </div><!-- /content -->
    </div><!-- /page -->
</body>
</html>