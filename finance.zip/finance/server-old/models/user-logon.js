﻿var UserLogon = function(cnf) {
    this.email = cnf.email,
    this.password = cnf.password
};

module.exports = UserLogon;
