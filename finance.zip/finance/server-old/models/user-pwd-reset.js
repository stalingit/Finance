﻿var UserPasswordReset = function(cnf) {
    this.email = cnf.email
};
module.exports = UserPasswordReset;
