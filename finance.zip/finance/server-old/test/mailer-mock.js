﻿var MailerMock = function () {   
};

MailerMock.prototype.sendPasswordResetHash = function (email, passwordResetHash) {

};

module.exports = MailerMock;
