<?php
	session_start();
/**
* this is the entry api point for the finance mobile app, 
* iT includes all the db operations for the methods
*/
error_reporting(0);


//include_once( "api-codes.php");
$db = mysqli_connect('localhost', 'root', '', 'multi_login');
$username = "";
	$email    = "";
	$errors   = array(); 

//if( isset( $_GET['action'] )){
if (isset($_GET['action']) && !empty($_GET['action'])) {

	$method = $_GET['action'];
	// call_user_func( $method );
	
	
	
	$response = $method();
} else {
	$response = new stdclass();
	$response->success = true;
	$response->msg = "Successfully added "; 
}
exit( json_encode( $response ));
function logout(){


		session_destroy();
		unset($_SESSION['user']);
		//header("location: ./index.html");
       $response = new stdclass();
       $response->success_logout = true;
				//$response->msg = "New user created"; 
	     return $response;	   

}

	
function register(){
global $db, $errors;
	$response = new stdclass();	
	//  validation if needed 
	// the code should be like this 
	if( $error ){ // for example if($_POST['dob'] <= 2000 )
		$response->success = false;
		$response->msg = "Age should be true8 or old";
		return $response;
	}
	
	// do the db operations 
	// all fields are in $_POST
	$userName = $_POST['firstName'];
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	// form validation: ensure that the form is correctly filled
		if (empty($firstName)) { 
			array_push($errors, "First Name is required"); 
		}
		if (empty($lastName)) { 
			array_push($errors, "Last Name is required"); 
		}
		
		if (empty($email)) { 
			array_push($errors, "Email is required"); 
		}
		// register user if there are no errors in the form
		
		if (count($errors) == 0) {
			$password = md5($password);//encrypt the password before saving in the database
			
			
			
			if (isset($_POST['txtUserType']) && !empty($_POST['txtUserType'])) {
				$user_type = $_POST['txtUserType'];
				$query = "INSERT INTO users (username, firstName, lastName, email, user_type, password) 
						  VALUES('$userName','$firstName','$lastName', '$email', '$user_type', '$password')";
				mysqli_query($db, $query);
				$_SESSION['success']  = "New user successfully created!!";
				$response->success_admin = true;
				$response->msg = "New user created"; 
	            return $response;
			}else{
				$query = "INSERT INTO users (username,firstName, lastName, email, user_type, password) 
						  VALUES('$userName','$firstName','$lastName', '$email', 'user', '$password')";
						  
					
						  
						  
						  
						  
						  
				mysqli_query($db, $query);

				// get id of the created user
				$logged_in_user_id = mysqli_insert_id($db);

				$_SESSION['user'] = getUserById($logged_in_user_id); // put logged in user in session
				$_SESSION['success']  = "You are now logged in";
				$response->success = true;
				$response->msg = "You are now logged in"; 
	            return $response;
				
				
				
				
				//header('location: index.php');				
			}
			
			
			
			
			
		}

	
	
}
// return user array from their id
	function getUserById($id){
		global $db;
		$query = "SELECT * FROM users WHERE id=" . $id;
		$result = mysqli_query($db, $query);

		$user = mysqli_fetch_assoc($result);
		return $user;
	}
// login
function login(){
global $db, $email, $errors;
	$response = new stdclass();	





// grap form values
		$email = $_POST['email'];
		$password = $_POST['password'];
		
		// make sure form is filled properly
		if (empty($email)) {
			array_push($errors, "Email is required");
		}
		if (empty($password)) {
			array_push($errors, "Password is required");
		}
		
		// attempt login if no errors on form
		if (count($errors) == 0) {
			$password = md5($password);

			$query = "SELECT * FROM users WHERE email='$email' AND password='$password' LIMIT 1";
			
			
			$results = mysqli_query($db, $query);

			if (mysqli_num_rows($results) == 1) { // user found
				// check if user is admin or user
				$logged_in_user = mysqli_fetch_assoc($results);
				
				
				if ($logged_in_user['user_type'] == 'admin') {

					//$_SESSION['user'] = $logged_in_user;
					//$_SESSION['success']  = "You are now logged in";
					//header('location: admin/home.php');		  
					$response->success_admin = true;
				    $response->msg = "You are now logged in"; 
	                return $response;	  
				}else{
					//$_SESSION['user'] = $logged_in_user;
					//$_SESSION['success']  = "You are now logged in";
					
					
					//header('location: index.php');
					$response->success = true;
				    $response->msg = "You are now logged in"; 
				   return $response;

					//header('location: index.php');
				}
			}else {
				array_push($errors, "Wrong username/password combination");
			}
		}
		
		
		
}
function isAdmin()
	{
		if (isset($_SESSION['user']) && $_SESSION['user']['user_type'] == 'admin' ) {
			return true;
		}else{
			return false;
		}
	}
?>