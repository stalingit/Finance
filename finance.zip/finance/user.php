﻿<?php
session_start();








?>
<!DOCTYPE html>
<html>
<head>
    <title>BookIt</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="./css/themes/1/conf-room1.min.css" rel="stylesheet" />
    <link href="./css/themes/1/jquery.mobile.icons.min.css" rel="stylesheet" />
    <link href="../../../lib/jqm/1.4.5/jquery.mobile.structure-1.4.5.min.css" rel="stylesheet" />
    <link href="./css/app.css" rel="stylesheet" />
    <script src="../../../lib/jquery/2.1.1/jquery-2.1.1.min.js"></script>
    <script src="js/sign-up.js" type="text/javascript"></script>
    <script src="../../../lib/jqm/1.4.5/jquery.mobile-1.4.5.min.js"></script>
</head>

<body>
    <div data-role="page" data-bookit-page="index">
        <div data-role="header" data-theme="c">
            <h1>Book It</h1>
        </div><!-- /header -->
        <div role="main" class="ui-content">
            <h2 class="mc-text-center">Registration Succeed</h2>
            <p class="mc-top-margin-1-5">Congratulations!  You are now registered with BookIt.</p>
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>
		<div>
				<?php  if (isset($_SESSION['user'])) : ?>
					<strong><?php echo $_SESSION['user']['username']; ?></strong>

					<small>
						<i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i> 
						<br>
						<a href="index.php" style="color: red;">logout</a>
						&nbsp; <a href="create_user.php"> + add user</a>
					</small>

				<?php endif ?>
			</div>
            <!-- <a href="sign-in.html" class="ui-btn ui-btn-b ui-corner-all">Sign In</a>-->
            <p></p>
        </div><!-- /content -->
    </div><!-- /page -->
</body>
</html>